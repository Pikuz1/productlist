import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-_services',
  template:'',
 
})
export class ServicesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
