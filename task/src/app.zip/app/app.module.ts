import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import{HttpModule} from '@angular/http';
import { AppComponent } from './app.component';
import { NavbarComponent } from './navbar/navbar.component';
import { HomeComponent } from './home/home.component';
import{routes} from './apps.routes';
import {RouterModule} from '@angular/router';
import{ItemServices} from './item.services';
import { ProductComponent } from './product/product.component';
import{SearchFilterPipe} from './custom.pipe';
import {FormsModule} from '@angular/forms';
import{RatingComponent} from './rating/rating.component';

@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    HomeComponent,
    ProductComponent,
    SearchFilterPipe,
    RatingComponent,
    ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(routes),
    HttpModule,
    FormsModule
  ],
  providers: [ItemServices],
  bootstrap: [AppComponent]
})
export class AppModule { }
