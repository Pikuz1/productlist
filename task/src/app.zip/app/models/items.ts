export interface Products {
    itemId: number;
    id: number;
    title: string;
    rating:any;
 }
 